﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace FastFood.Models
{
    public class Order
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Price { get; set; }
    }
}
