﻿using FastFood.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FastFood.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MenuController : ControllerBase
    {
        FoodDbContext foodDbContext;

        public MenuController(FoodDbContext fg)
        {
            foodDbContext = fg;
        }

        [HttpGet]
        public IActionResult GetMenus()
        {
            var fg = foodDbContext.Menus;
            return Ok(fg);
        }

    }
}
